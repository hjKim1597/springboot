package com.simple.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
