package com.hj00.prac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SelfPracApplicationTests {

	@Test
	void contextLoads() {
	}

}
