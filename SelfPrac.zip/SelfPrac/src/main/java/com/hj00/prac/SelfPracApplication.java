package com.hj00.prac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SelfPracApplication {

	public static void main(String[] args) {
		SpringApplication.run(SelfPracApplication.class, args);
	}

}
